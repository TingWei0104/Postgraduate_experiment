Fold	Training.txt	Validation.txt Test.txt	
Fold1	S1, S2, S3	S4		S5	
Fold2	S2, S3, S4	S5		S1	
Fold3	S3, S4, S5	S1		S2	
Fold4	S4, S5, S1	S2		S3	
Fold5	S5, S1, S2	S3		S4	

先不使用驗證集，以80%作為訓練集，20%為測試集，如Fold1訓練集為S1+S2+S3+S4，驗證集為S5

